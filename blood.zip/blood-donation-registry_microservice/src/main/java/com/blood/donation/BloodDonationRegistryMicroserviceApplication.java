package com.blood.donation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BloodDonationRegistryMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloodDonationRegistryMicroserviceApplication.class, args);
	}

}
