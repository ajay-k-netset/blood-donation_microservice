package com.bloodDonation.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class BloodDonationServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloodDonationServerApplication.class, args);
	}

}
